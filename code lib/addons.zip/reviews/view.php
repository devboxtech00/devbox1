<?php 
$getuser = get_user_by( 'slug', get_query_var( 'author_name' ) );
$getuserid =  $getuser->ID;
$getusername = $getuser->display_name;
?>
<div class="reviews_section">
	<div class="reviwe_from_sec">
		<div class="review_from_chatplguin">
			<form class="user_review_from" name="user_review_from" method="post">
			<div class="form-group">
				<label for="exampleInputEmail1">Navn:</label>
				<input type="text" class="form-control name_rvfrm" name="name_rvfrm" required>
			</div>
			<div class="form-group">
				<label for="exampleInputEmail1">Tittel:</label>
				<input type="text" class="form-control title_rvfrm" name="title_rvfrm"  required>
			</div>
			<div class="form-group">
				<label for="exampleInputEmail1">Veilederens navn:</label>
				<input type="text" class="form-control supervisor_rvfrm" name="supervisor_rvfrm"  required>
				<input type="number" class="userid_rvfrm" value="<?php echo $getuserid; ?>" name="userid_rvfrm" hidden>
				<input type="text" class="username_rvfrm" value="<?php echo $getusername; ?>" name="userid_rvfrm" hidden>
			</div>
			<div class="rating_wrapwer">
				<div class="row">
					<div class="col-md-6 rating_col">
						<label for="exampleFormControlTextarea2">Rating:</label>
					</div>
					<div class="col-md-6 ratingStar_col">
							<div class="rating">
								<input type="radio" name="rating_rvfrm" value="5" id="5"><label for="5">☆</label>
								<input type="radio" name="rating_rvfrm" value="4" id="4"><label for="4">☆</label>
								<input type="radio" name="rating_rvfrm" value="3" id="3"><label for="3">☆</label>
								<input type="radio" name="rating_rvfrm" value="2" id="2"><label for="2">☆</label>
								<input type="radio" name="rating_rvfrm" value="1" id="1"><label for="1">☆</label>
						</div>
					</div>
				</div>
			</div>
			<div class="form-group d-block">
			<label for="exampleFormControlTextarea2 mb-2">Review:</label>
			<textarea class="form-control review_rvfrm" name="review_rvfrm" id="exampleFormControlTextarea2" rows="3"></textarea>
			</div>
			<button type="submit" class="btn reviewbuttons" name="user_review_from">Submit</button>
			<button class="btn reviewbuttons hide_review_from">Cancel</button>
			</form>
		</div>
		<div class="active_button">
			<button class="btn create_review">Create your own review</button>	
		</div>
	</div>
	<?php 
	$allratings = [];
	$loop_area1 = new WP_Query(array(
		'post_type' => 'consultant_reviews',
		'posts_per_page' => -1,
		'orderby'  => 'post_id',
		'order' => 'DESC',
		'author' => $getuserid,
		));
while ($loop_area1->have_posts() ) : $loop_area1->the_post(); 
$ratings    = get_post_meta(get_the_ID(),'cr_reviewer_rating',true);
array_push($allratings, $ratings);
endwhile; 

if(!empty($allratings)):
//var_dump($allratings);
$totalCopunt = count($allratings);
$totalSum =  array_sum($allratings);
$avarage = $totalSum/$totalCopunt;
$avarage = round($avarage, 1);
//echo $totalCopunt ."  ".$totalSum."  ".$avarage;
 ?>

<div class="avarage_ratings">
    <p>Average Rating:</p>
	<div class="Stars" style="--rating:<?php echo $avarage; ?>"></div>
	<p><?php echo $totalCopunt; ?> reviews</p>
</div>
<?php endif;?>
	
<?php 
$paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1; 
		$loop_area1 = new WP_Query(array(
		'post_type' => 'consultant_reviews',
		'posts_per_page' => 15,
		'orderby'  => 'post_id',
		'order' => 'DESC',
		'author' => $getuserid,
		'paged' => $paged
		));
while ($loop_area1->have_posts() ) : $loop_area1->the_post(); 



$currentPostId = get_the_ID();
	$reviewed_user      = get_post_meta($currentPostId,'cr_reviewed_user',true);
    $reviewed_name      = get_post_meta($currentPostId,'cr_reviewer_name',true);
    $reviewer_title     = get_post_meta($currentPostId,'cr_reviewer_title',true);
    $reviewer_email     = get_post_meta($currentPostId,'cr_reviewer_email',true);
    $reviewer_rating    = get_post_meta($currentPostId,'cr_reviewer_rating',true);
    $reviewer_adminbox  = get_post_meta($currentPostId,'cr_reviewer_adminbox',true);
    $reviewer_suprviser = get_post_meta($currentPostId,'cr_reviewer_suprviser',true);
?>
	<div class="reviews_wraper">
		<div class="rating_names">
			<div class="show_rating">
				<?php if($reviewer_rating == 1){  ?>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star"></span>
					<span class="fa fa-star"></span>
					<span class="fa fa-star"></span>
					<span class="fa fa-star"></span>
				<?php } else if($reviewer_rating == 2){  ?>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star"></span>
					<span class="fa fa-star"></span>
					<span class="fa fa-star"></span>
				<?php } else if($reviewer_rating == 3){?>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star"></span>
					<span class="fa fa-star"></span>
				<?php } else if($reviewer_rating == 4){?>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star"></span>
				<?php } else if($reviewer_rating == 5){?>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
					<span class="fa fa-star checked"></span>
				<?php } ?>

			</div>
			<div class="info">
				<p><span><?php echo get_the_date(); ?></span> by <span><?php echo $reviewed_name; ?></span></p>
			</div>
		</div>
		<div class="review_titlle">
			<p><?php echo $reviewer_title; ?></p>
		</div>
		<div class="review_body">
		<?php the_content(); ?>
		</div>
		<div class="review_admincomment">
		<?php wpautop( $reviewer_adminbox, true) ?>
		</div>
		
	</div>
<?php endwhile; ?>
<?php wp_pagenavi(array( 'query' => $loop_area1));?>
</div>
<script>
jQuery(document).ready(function ($) {
	$(".user_review_from").on('submit', function(e){
		e.preventDefault();
		var navn = $($(this).find(".name_rvfrm")).val();
		 var tittel = $($(this).find(".title_rvfrm")).val();
		 var vgeilederens = $($(this).find(".supervisor_rvfrm")).val();
		 var review = $($(this).find(".review_rvfrm")).val();
		 var rating = $($(this).find("input[name='rating_rvfrm']:checked")).val();
		 var userid = $($(this).find(".userid_rvfrm")).val();  
		 var username = $($(this).find(".username_rvfrm")).val();  

		 var siteurl = '<?php echo home_url(); ?>';


		 console.log(navn,tittel,vgeilederens,review,rating,userid,username);
		 
   $.ajax({
	 url: siteurl+'/wp-admin/admin-ajax.php',
	 data: {'action':'addreview',
			'name_rvfrm':navn,
            'title_rvfrm':tittel,
            'supervisor_rvfrm':vgeilederens,
            'rating_rvfrm':rating,
            'review_rvfrm':review,
            'userid_rvfrm':userid,
            'username_rvfrm':username
		   },
	 type:'post',
	 success: function(result){
	  //console.log("sucess");
	  $(".review_from_chatplguin").css({
				'max-height': '0',
				'transition':' max-height 0.25s ease-in'
				})	
			$('.create_review').css('display','block');		
	  window.alert("Thank you! Your review has been received and will be posted soon.");

   
	 var result =$(result)
	 //console.log(result);
	 },
	 error:function(result){
	   console.warn(result);
	  // location.reload();
	 }
   })
  });
});
</script>