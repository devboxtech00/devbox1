<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce\Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header(); ?>
   <section class="hire_designer cmn_gap hdr_top_gap">
      <div class="container">
	  <div class="single_prdt">

 
	<?php
		/**
		 * woocommerce_before_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
		 * @hooked woocommerce_breadcrumb - 20
		 */
		do_action( 'woocommerce_before_main_content' );
	?>

		<?php while ( have_posts() ) : ?>
			<?php the_post(); ?>

			<?php wc_get_template_part( 'content', 'single-product' ); ?>

		<?php endwhile; // end of the loop. ?>

	<?php
		/**
		 * woocommerce_after_main_content hook.
		 *
		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
		 */
		do_action( 'woocommerce_after_main_content' );
	?>

	<?php
		/**
		 * woocommerce_sidebar hook.
		 *
		 * @hooked woocommerce_get_sidebar - 10
		 */
		//do_action( 'woocommerce_sidebar' );
	?>
    </div>
         </div>
   </section>
   <section>
   <div class="container">
   <div class="row ">
   <div class="col-md-7 ">
   <?php
	global $product;
    $attachment_ids = $product->get_gallery_attachment_ids();
    echo '<div class=" galley_detilspg row">';
    foreach( array_slice( $attachment_ids, 0,100 ) as $attachment_id ) {
       $thumbnail_url = wp_get_attachment_image_src( $attachment_id, 'thumbnail' )[0];
	   $light_box_url = wp_get_attachment_image_src( $attachment_id, 'full' )[0];
       echo '<div class="col-md-4" style="margin-top:30px;">
	   <div class="hover_state_woo hovrico">
	   <a href="' . $light_box_url . '" data-fancybox="gallery" data-caption="">
	   <img  class="galley_detilspg_img" src="' . $thumbnail_url . '">
	   <img class="like_hover" src="https://newwebdev.wordpress-developer.us/by-biehle/wp-content/uploads/2021/03/like.svg" alt="">
	   </a>
	 
	 </div></div>';
	}
    echo '</div>'; ?>
              
              </div>
              <div class="col-md-5">
              
              <div class="product-destilsfaq">
			<div class="accordine-holder supported">
                        <div id="accordion">
						<?php $i=1;
						while (have_rows('long_description_product_lngdes')): the_row(); ?>
                            <div class="card">
                              <div id="heading<?php echo $i; ?>">
                                  <button id="hb<?php echo $i; ?>" class="title-holder collapsed" data-toggle="collapse" data-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo $i; ?>">
                                    <span><?php echo get_sub_field('title_product_lngdes'); ?></span>
                                  </button>
                              </div>
                          
                              <div id="collapse<?php echo $i; ?>" class="content-box collapse" aria-labelledby="heading<?php echo $i; ?>" data-parent="#accordion">
                                  <p><?php echo get_sub_field('description_product_lngdes'); ?></p>
                              </div>
                            </div>
                         <?php $i++; endwhile; ?>

                            
                          </div>
                    </div>
                 
		</div>
              
              
              </div>

      <div class="container">
   <div class="row prb-dtls-inner pkg_slider_cntnr">
              <div class="col-md-12 prb-dtls-innerleft">
                  <h2>Packaging & Stationary</h2>
                  <!-- <div class="mul_p">
                     <p><?php // echo get_field('description_sg_woo_sinp'); ?></p>
                  </div> -->

                  <div class="package_slider">
                  <?php 
                  $params = array(
                  'posts_per_page' => -1,
                   'post_type' => 'product',
                   'product_cat' => 'packaging',
                    );
                    $wc_query = new WP_Query($params); 
                   if ($wc_query->have_posts()) :  
                   while ($wc_query->have_posts()) : $wc_query->the_post();  ?>
                   <div>
                   <div class="pch_slider_box">
                      <a href="<?php the_permalink(); ?>"><img src="<?php echo get_the_post_thumbnail_url(); ?>" alt=""></a>
                      <h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a> </h2>
					   <div class="product_sld_meta"><a href="<?php the_permalink();?>"><?php the_excerpt()?></a></div>
                      </div>
                       </div>
                       <?php endwhile; ?>
                  <?php wp_reset_postdata();  ?>
                  <?php else:  ?>
                  <p><?php _e( 'No Products' );  ?></p>
                  <?php endif; ?>
                       </div>
                     </div>
            </div>
      		
         </div>
         </div>

   </section>
   <section class="hm_service">
      <div class="container">


      <?php if (have_rows('sliders_pg_woop')): ?>
      <div id="paper_guide"class="row prb-dtls-inner">
      <div class="col-md-6 prb-dtls-innerleft">
      <h2><?php echo get_field('title_pg_woop'); ?></h2>
      <div class="mul_p">
      <p><?php echo get_field('descriptions_pg_woop'); ?></p>
      </div></div>

      <div class="col-md-6 prb-dtls-innerright">
      <div class="paper-guide-slider">
      <div class="paper-guide-imggslider">
      <?php while (have_rows('sliders_pg_woop')): the_row(); ?>
      <div class="paper-guide-bigimg">
      <figure>
      <img src="<?php echo get_sub_field('slider_images_pg_woop') ['url']; ?>" alt="<?php echo get_sub_field('slider_images_pg_woop')['alt']; ?>">         
      </figure>
      <div class="paper_slider_desc">
         <?php  echo get_sub_field('slider_description_pg_woop');  ?>
      </div>
      </div>
      <?php endwhile; ?>
             
      </div>
      </div>
      </div>
      </div>
      <?php endif; ?>


      <?php if( have_rows('list_items_sg_woo_sinp') ):  ?>

           <div id="size_guide"class="row prb-dtls-inner">
              <div class="col-md-6 prb-dtls-innerleft">
                  <h2><?php echo get_field('title_sg_woo_sinp'); ?></h2>
                  <div class="mul_p">
                     <p><?php echo get_field('description_sg_woo_sinp'); ?></p>
                  </div>

                  <div class="sizebtnss">
                    
                     <?php while (have_rows('list_items_sg_woo_sinp')): the_row(); ?>
                     <div>
                        <div class="sizebox"><a href="javascript:void(0)"><?php echo get_sub_field('single_list_sg_woo_sinp'); ?></a></div>
                        </div>
                      <?php endwhile; ?>
                

                  </div>
            </div>
      		<div class="col-md-6 prb-dtls-innerright">
              
               <div class="size-guide-slider">
                  <div class="size-guide-imggslider">
                  <?php while (have_rows('image_demo_sg_woo_sinp')): the_row(); ?>
                     <div class="sizeguide-bigimg">
                     
                        <figure>
                        <img src="<?php echo get_sub_field('single_image_demo') ['url']; ?>" alt="<?php echo get_sub_field('single_image_demo')['alt']; ?>">         
                        </figure>
                     </div>
                    
                    <?php endwhile; ?>
             
                  </div>
               </div>



            </div>
         </div>

         <?php endif; ?>

         <?php if( have_rows('guide_table_head_mg_woo_sinp') ):  ?>

         <div id="metrial_guide" class="row prb-dtls-inner">
              <div class="col-md-6 prb-dtls-innerleft">
                  <h2><?php echo get_field('title_mg_woo_sinp'); ?></h2>
                  <div class="mul_p">
                     <p><?php echo get_field('description_mg_woo_sinp'); ?></p>
                  </div>
                  <div class="bnr_top">
                     <a href="javascript:void(0)" class="btn">Learn More</a>
                  </div>
            </div>

            <div class="col-md-6 prb-dtls-innerright">
               <div class="guide-chrt">
                  <div class="table-responsive">
                  <table class="table">
                   <thead>
                     <tr>
                     <?php while (have_rows('guide_table_head_mg_woo_sinp')): the_row(); ?>
                
                       <th><?php echo get_sub_field('table_head_mg_woo_sinp'); ?></th>
                      <?php endwhile; ?>
                     </tr>
                   </thead>
                   <tbody>
                   <?php while (have_rows('guide_table_body')): the_row(); ?>
                     <tr>
                       <td> <?php echo get_sub_field('size_guide_table_body_woo_snp'); ?></td>
                       <?php while (have_rows('options_size_guide_table_body_woo_snp')): the_row(); ?>
                       <td><img src="<?php echo get_sub_field('chek_icon_size_guide_table_body_woo_snp') ['url']; ?>" alt="<?php echo get_sub_field('chek_icon_size_guide_table_body_woo_snp')['alt']; ?>">     </td>
                       <?php endwhile; ?>
                     </tr>
                   <?php endwhile; ?>
                   </tbody>
                 </table>
              </div>

               </div>
            </div>
         </div>
       <?php endif; ?>


       <?php if (have_rows('table__vd_woo_sinp')):  ?>
         <div id="vol_discnt" class="row prb-dtls-inner">
              <div class="col-md-6 prb-dtls-innerleft">
                  <h2><?php echo get_field('title_vd_woo_sinp'); ?></h2>
                  <div class="mul_p">
                     <p><?php echo get_field('description_vd_woo_sinp'); ?></p>
                  </div>
                  <div class="discount-chart">
                     <div class="table-responsive">
                     <table class="table table-bordered">
                         <tbody>
                         <?php while (have_rows('table__vd_woo_sinp')): the_row(); ?>
                           <tr>
                           <?php while (have_rows('table_row_vd_woo_sinp')): the_row(); ?>
                             <td><?php echo get_sub_field('table_data_vd_woo_sinp'); ?></td>
                             <?php endwhile; ?>
                           </tr>
                           <?php endwhile; ?>
                         </tbody>
                       </table>
                     </div>
                  </div>
                  <div class="bnr_top">
                     <a href="#" class="btn">SEE PRICING OVERVIEW</a>
                  </div>

            </div>
            <div class="col-md-6 prb-dtls-innerright">
               <figure>
               <img src="<?php echo get_field('section_image__vd_woo_sinp') ['url']; ?>" alt="<?php echo get_field('section_image__vd_woo_sinp')['alt']; ?>"> 
               </figure>
            </div>
         </div>
<?php endif; ?>


<?php $quality = get_field('description_qa_woo'); 

if(!empty($quality)): 
?>


         <div class="row prb-dtls-inner">
              <div class="col-md-6 prb-dtls-innerleft">
                  <h2><?php echo get_field('title_qa_woo'); ?></h2>
                  <div class="mul_p">
                  <p><?php echo get_field('description_qa_woo'); ?></p>
                  </div>
                  <div class="discount-chart"></div>
                  <div class="bnr_top">
                     <a href="javascript:void(0)" class="btn">Learn More</a>
                  </div>

            </div>
            <div class="col-md-6 prb-dtls-innerright">
               
               <div class="ser_im silk_icn_otr">
                  <div class="imm_in hover_imgs">
                        <a href="#">
                   <img src="<?php echo get_field('image_qa_woo') ['url']; ?>" alt="<?php echo get_field('image_qa_woo')['alt']; ?>"> 
                        </a>
                        <div class="silk_icn">
                   <img src="<?php echo get_field('icon_qa_woo') ['url']; ?>" alt="<?php echo get_field('icon_qa_woo')['alt']; ?>"> 
                        </div>
                     </div>
               </div>

            </div>
         </div>

<?php endif; ?>

            
         </div>
      
   </section>






<!-- Modal -->
<div class="modal fade" id="sampleorder" tabindex="-1" role="dialog" aria-labelledby="sampleorder" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLongTitle">Order Type</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<ol>
<li>Select ‘Regular Order’ to place a full order above 10 pieces. Production and shipping lead time is 4 weeks. </li>
<li>Select ‘Sample Order’ to order a sample of your custom scarf design if you want to check the quality and review your design, size, and material choice before placing your full order. Production and shipping lead time for samples is 3 weeks.</li>
</ol>
</div>
</div>
</div>
</div>


<!-- Modal -->
<div class="modal fade" id="quntydis" tabindex="-1" role="dialog" aria-labelledby="quntydis" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" role="document">
<div class="modal-content">
<div class="modal-header">
<h5 class="modal-title" id="exampleModalLongTitle">Volume Discounts</h5>
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<div class="discount-chart">
<p><?php echo get_field('description_vd_woo_sinp'); ?></p>
                     <div class="table-responsive">
                     <table class="table table-bordered">
                         <tbody>
                         <?php while (have_rows('table__vd_woo_sinp')): the_row(); ?>
                           <tr>
                           <?php while (have_rows('table_row_vd_woo_sinp')): the_row(); ?>
                             <td><?php echo get_sub_field('table_data_vd_woo_sinp'); ?></td>
                             <?php endwhile; ?>
                           </tr>
                           <?php endwhile; ?>
                         </tbody>
                       </table>
                     </div>
                  </div>
</div>
</div>
</div>
</div>

<?php
get_footer();

/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */
