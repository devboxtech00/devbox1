<?php 
//create post_type_user_review
if( !class_exists( 'Purplereading_Consultations_consultantReviews') ){  
        class  Purplereading_Consultations_consultantReviews {
                function __construct() {
                    add_action( 'init', array( $this, 'create_consultantReview_post_type' ) );
                    add_action('add_meta_boxes', array($this, 'my_custom_add_meta_box'), 10, 2);
                    add_action('pre_get_posts', array($this,'author_cpt_filter'));
                }
        
                public function create_consultantReview_post_type(){
                    //UI 
                    $labels = array(
                        'name'                => _x( 'Consultant Reviews', 'Post Type General Name', 'purplereading-consultation' ),
                        'singular_name'       => _x( 'Consultant Review', 'Post Type Singular Name', 'purplereading-consultation' ),
                        'menu_name'           => __( 'Consultant Reviews', 'purplereading-consultation' ),
                        'parent_item_colon'   => __( 'Parent Consultant Review', 'purplereading-consultation' ),
                        'all_items'           => __( 'All Consultant Reviews', 'purplereading-consultation' ),
                        'view_item'           => __( 'View Consultant Review', 'purplereading-consultation' ),
                        'add_new_item'        => __( 'Add New Consultant Review', 'purplereading-consultation' ),
                        'add_new'             => __( 'Add New', 'purplereading-consultation' ),
                        'edit_item'           => __( 'Edit Consultant Review', 'purplereading-consultation' ),
                        'update_item'         => __( 'Update Consultant Review', 'purplereading-consultation' ),
                        'search_items'        => __( 'Search Consultant Review', 'purplereading-consultation' ),
                        'not_found'           => __( 'Not Found', 'purplereading-consultation' ),
                        'not_found_in_trash'  => __( 'Not found in Trash', 'purplereading-consultation' ),
                    );
                    
                    // options 
                    
                    $args = array(
                        'label'               => __( 'Consultant Reviews', 'purplereading-consultation' ),
                        'description'         => __( 'ALL Consultant Review Details', 'purplereading-consultation' ),
                        'labels'              => $labels,
                        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
                        'taxonomies'          => array( 'genres' ),
                        'hierarchical'        => true,
                        'public'              => true,
                        'show_ui'             => true,
                        'show_in_menu'        => true,
                        'show_in_nav_menus'   => false,
                        'show_in_admin_bar'   => true,
                        'menu_position'       => 20,
                        'menu_icon'           => 'dashicons-superhero-alt',
                        'can_export'          => true,
                        'has_archive'         => true,
                        'exclude_from_search' => false,
                        'publicly_queryable'  => false,
                        'capability_type'     => 'post',
                        'show_in_rest' => true,
                        'rewrite' => array( 'slug' => 'consultant_reviews' ),

                    );
                    
                    // Registering your Custom Post Type
                    register_post_type( 'consultant_reviews', $args );
            }

        


//custom meta boxes

function my_custom_add_meta_box($post_type, $post) {
    $my_post_type = 'consultant_reviews';


   }

   function author_cpt_filter($query) {
    if ( !is_admin() && $query->is_main_query() ) {
      if ($query->is_author()) {
        $query->set('post_type', array('post', 'consultant_reviews'));
        $query->set('post_per_page', 15);

      }
    }
}


}
}