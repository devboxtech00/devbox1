<?php 
function cr_meta_box() {
	add_meta_box('cr','Consultant Review','cr_callback','consultant_reviews');
}
add_action('add_meta_boxes','cr_meta_box');

function cr_callback( $post ) {
	wp_nonce_field('cr_save','cr_meta_box_nonce');
	$reviewed_user      = get_post_meta($post->ID,'cr_reviewed_user',true);
    $reviewed_name      = get_post_meta($post->ID,'cr_reviewer_name',true);
    $reviewer_title     = get_post_meta($post->ID,'cr_reviewer_title',true);
    $reviewer_email     = get_post_meta($post->ID,'cr_reviewer_email',true);
    $reviewer_rating    = get_post_meta($post->ID,'cr_reviewer_rating',true);
    $reviewer_adminbox  = get_post_meta($post->ID,'cr_reviewer_adminbox',true);
    $reviewer_suprviser = get_post_meta($post->ID,'cr_reviewer_suprviser',true);
   
	?>
 <table class="review_innerfeilds">
  <tr><th style="width:30%">  
    <label>Reviewed User</label>
  </th>
  <td>
    <input type="text" name="reviewed_user_field" 
    value="<?php if(!empty( $reviewed_user)){
     echo $reviewed_user;
    }; ?>">
   </td>
   </tr>
   <tr><th style="width:30%">  
    <label>Review Title</label>
  </th>
  <td>
    <input type="text" name="review_title_field" 
    value="<?php if(!empty( $reviewer_title)){
     echo $reviewer_title;
    }; ?>">
   </td>
   </tr>
    <tr><th style="width:30%"><label for="">Reviewer Name</label>
    </th>
    <td>
    <input type="text" name="reviewer_name_field" 
    value="<?php if(!empty($reviewed_name)):
    echo $reviewed_name; endif; ?>">
    </td>
    </tr>
    <tr><th style="width:30%">  
    <label for="">Enter Email</label>
    </th>
    <td>
    <input type="text" name="reviewer_email_field" 
    value="<?php if(!empty($reviewer_email)):
     echo $reviewer_email; endif; ?>">
     </td>
    </tr>
     <tr><th style="width:30%"> 
    <label for="">Rating</label>
    </th>
    <td>
    <select id="user_ratings_inner" name="rating_email_field" >
        <option value="1">1 star</option>
        <option value="2">2 stars</option>
        <option value="3">3 stars</option>
        <option value="4">4 stars</option>
        <option value="5">5 stars</option>
    </select>
    </td>
    </tr>
     <tr><th style="width:30%">  
    <label for="">Admin Response to Review</label>
    </th>
    <td>
    <textarea  name="reviewer_adminbox_field">
        <?php if(!empty($reviewer_adminbox)):
        echo $reviewer_adminbox; endif; ?>
     </textarea>
     </td>
     </tr>
     <tr><th style="width:30%">  
    <label for="">Veilederens navn</label>
        </th>
    <td>
    <input type="text"   name="reviewer_supervisor_field" 
        value="<?php if(!empty($reviewer_suprviser)):
        echo  $reviewer_suprviser; endif; ?>">
     </td>
        </tr>
</table>

<script>
    jQuery(document).ready(function ($) {
$("#user_ratings_inner option").each(function(){
 var rates = '<?php echo $reviewer_rating; ?>'   
 var getvalue =  $($(this)).val();
  if($($(this)).val() == rates){
    $($(this)).attr("selected", "selected");
    console.log($($(this)).val());
  }
  //console.log(getvalue);
});
});
</script>
    <?php
}

function cr_save( $post_id ) {
 
	if( ! isset($_POST['cr_meta_box_nonce'])) {
		return;
	}
 
	if( ! wp_verify_nonce( $_POST['cr_meta_box_nonce'], 'cr_save') ) {
		return;
	}
 
	if( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) {
		return;
	}
 
	if( ! current_user_can('edit_post', $post_id)) {
		return;
	}
	// $consultaionReview = [
    //     'reviewed_user' => $_POST['reviewed_user_field'],
    //     'reviewer_name' => $_POST['reviewer_name_field'],
    //     'reviewer_email'=> $_POST['reviewer_email_field'],
    //     'reviewer_rating'=> $_POST['rating_email_field'],
    //     'reviewer_adminbox'=> $_POST['reviewer_adminbox_field'],
    //     'reviewer_suprviser'=> $_POST['reviewer_supervisor_field']
    //    ];
   
        $reviewed_user      = $_POST['reviewed_user_field'];
        $reviewed_title      = $_POST['review_title_field'];
        $reviewer_name      = $_POST['reviewer_name_field'];
        $reviewer_email     = $_POST['reviewer_email_field'];
        $reviewer_rating    = $_POST['rating_email_field'];
        $reviewer_adminbox  = $_POST['reviewer_adminbox_field'];
        $reviewer_suprviser = $_POST['reviewer_supervisor_field'];
       
 
	update_post_meta( $post_id,'cr_reviewed_user',      $reviewed_user);
    update_post_meta( $post_id,'cr_reviewer_name',      $reviewer_name);
    update_post_meta( $post_id,'cr_reviewer_title',      $reviewed_title);
    update_post_meta( $post_id,'cr_reviewer_email',     $reviewer_email);
    update_post_meta( $post_id,'cr_reviewer_rating',    $reviewer_rating);
    update_post_meta( $post_id,'cr_reviewer_adminbox',  $reviewer_adminbox);
    update_post_meta( $post_id,'cr_reviewer_suprviser', $reviewer_suprviser);

}
add_action('save_post','cr_save');

function get_personal_details($array_key) {

    $consultaionReview = get_post_meta($post->ID,'_cr_key',false);
    return $consultaionReview[0][$array_key];
}


add_action( 'wp_ajax_nopriv_addreview', 'addreview_ajax' );
add_action( 'wp_ajax_addreview', 'addreview_ajax' );

function addreview_ajax(){

    $name = $_POST['name_rvfrm'];
    $title = $_POST['title_rvfrm'];
    $supervisor = $_POST['supervisor_rvfrm'];
    $rating = $_POST['rating_rvfrm'];
    $review = $_POST['review_rvfrm'];
    $userid = $_POST['userid_rvfrm'];
    $username = $_POST['username_rvfrm'];
    

    $postName = $name.'@'.date('Y-m-d H:i');
    $new_postS = array(
		'post_name'  => $postName,
        'post_title' => $postName,
        'post_content' => $review,
         'post_author' => $userid,
        'post_status' => 'pending',
        'post_date' => date('Y-m-d H:i:s'),
        'post_type' => 'consultant_reviews',
        'meta_input' => array(
            'cr_reviewed_user' => $username ,
            'cr_reviewer_name' => $name,
            'cr_reviewer_title' => $title,
            'cr_reviewer_email'=> "",
            'cr_reviewer_rating'=> $rating,
            'cr_reviewer_adminbox'=> "",
            'cr_reviewer_suprviser'=> $supervisor,
		)
       );

    wp_insert_post($new_postS);

    //echo  $name." ". $title." ".$supervisor." ".$rating." ".$review." ".$userid." ".$username;




}

  

