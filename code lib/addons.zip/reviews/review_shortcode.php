<?php 
if( !class_exists( 'Purplereading_Consultations_consultantReviews_shortcode') ){  
        class  Purplereading_Consultations_consultantReviews_shortcode {
                function __construct() {
                    add_shortcode( 'consultants_reviews', array( $this, 'add_shortcodeconsultant_revie' ) );
                }

                function add_shortcodeconsultant_revie(){
                    ob_start(); 
                    require_once( PURPLEREADING_CONSULTATIONS_PATH . '/addons/reviews/view.php' );
                    return ob_get_clean();
                }







        }
    }

        